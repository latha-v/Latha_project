package wrapper;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browser_launch {
 WebDriver dr;
 
public  WebDriver launch(String browser , String url)
{
	

	switch (browser)
	{
	case "chrome" :
	{
		System.setProperty("webdriver.chrome.driver", "src/test/resources/Drivers/chromedriver.exe");
		dr= new ChromeDriver();
		break;
	}
	case "firefox":
	{
		System.setProperty("webdriver.gecko.driver","src/test/resources/Drivers/geckodriver.exe");
		dr= new FirefoxDriver();
		
	}
	}
	dr.manage().window().maximize();
	dr.get(url);
	dr.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	return dr;

	
}
}
